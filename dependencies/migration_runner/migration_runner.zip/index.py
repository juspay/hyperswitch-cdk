import json
import boto3
import os
import psycopg2
import sqlparse

secrets_manager = boto3.client('secretsmanager')
s3_client = boto3.client('s3')

def connect_to_database():
    secret_arn = os.environ['DB_SECRET_ARN']
    secret_value_response = secrets_manager.get_secret_value(SecretId=secret_arn)
    db_credentials = json.loads(secret_value_response['SecretString'])
    print(db_credentials)
    return psycopg2.connect(
        host=db_credentials["host"],
        user=db_credentials["username"],
        password=db_credentials["password"],
        dbname=db_credentials["dbname"],
        port=int(db_credentials["port"])
    )

def execute_queries(queries, connection):
    parsed_queries = sqlparse.split(queries)
    with connection.cursor() as cursor:
        for query in parsed_queries:
            if query:
                print("query: ", query)
                cursor.execute(query)
    connection.commit()

def db_handler(event, context):
    s3_Bucket_Name = os.environ['SCHEMA_BUCKET']
    s3_File_Name = os.environ['SCHEMA_FILE_KEY']

    try:
        object = s3_client.get_object(Bucket=s3_Bucket_Name, Key=s3_File_Name)
        body = object['Body']

        content = body.read().decode('utf-8')

        connection = connect_to_database()
        execute_queries(content, connection)
        connection.close()

        return {
            'statusCode': 200,
            'body': json.dumps('SQL queries executed successfully!')
        }

    except Exception as err:
        print(f"Error: {err}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {err}")
        }